package com.library.cat.dto;

import java.time.LocalDate;

public class IndBookResponse extends BaseResponse {

	private Long bookId;

	private String description;

	private LocalDate publicationYear;

	private Long authorId;

	private Long categoryId;

	public Long getBookId() {
		return bookId;
	}

	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getPublicationYear() {
		return publicationYear;
	}

	public void setPublicationYear(LocalDate publicationYear) {
		this.publicationYear = publicationYear;
	}

	public Long getAuthorId() {
		return authorId;
	}

	public void setAuthorId(Long authorId) {
		this.authorId = authorId;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	@Override
	public String toString() {
		return "IndBookResponse [bookId=" + bookId + ", description=" + description + ", publicationYear="
				+ publicationYear + ", authorId=" + authorId + ", categoryId=" + categoryId + "]";
	}
	
	
}

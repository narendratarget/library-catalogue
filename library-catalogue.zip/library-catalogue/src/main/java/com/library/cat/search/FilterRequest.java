package com.library.cat.search;

public class FilterRequest {

	private String filterType;
	private String filterValue;

	public FilterRequest(String filter) {
		if (filter.contains(":")) {

			this.filterType = filter.split(":")[0];
			this.filterValue = filter.split(":")[1];
		}else {
			this.filterType=filter;
			this.filterValue=null;
		}
	}

	public String getFilterType() {
		return filterType;
	}

	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}

	public String getFilterValue() {
		return filterValue;
	}

	public void setFilterValue(String filterValue) {
		this.filterValue = filterValue;
	}
	
	

}

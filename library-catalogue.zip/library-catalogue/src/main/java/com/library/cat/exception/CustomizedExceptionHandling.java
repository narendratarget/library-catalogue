package com.library.cat.exception;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.library.cat.dto.BaseResponse;

@RestControllerAdvice
public class CustomizedExceptionHandling extends ResponseEntityExceptionHandler {

	@ExceptionHandler(DataNotFoundException.class)
	public BaseResponse handleInvalidRequestException(DataNotFoundException exception, WebRequest webRequest) {
		BaseResponse response = new BaseResponse();
		response.setErrorCode(exception.getErrorCode());
		response.setErrorDesc(exception.getErrorDesc());
		return response;
	}
	
	@ExceptionHandler(InvalidRequestException.class)
	public BaseResponse handleInvalidRequestException(InvalidRequestException exception, WebRequest webRequest) {
		BaseResponse response = new BaseResponse();
		response.setErrorCode(exception.getErrorCode());
		response.setErrorDesc(exception.getErrorDesc());
		return response;
	}
}
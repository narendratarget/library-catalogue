package com.library.cat.dto;

public class BaseResponse {

	private String errorCode;
	private String errorDesc;
	private String status;
	
	private Long txnId;
	
	

	public Long getTxnId() {
		return txnId;
	}

	public void setTxnId(Long txnId) {
		this.txnId = txnId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "BaseResponse [errorCode=" + errorCode + ", errorDesc=" + errorDesc + ", status=" + status + "]";
	}

}

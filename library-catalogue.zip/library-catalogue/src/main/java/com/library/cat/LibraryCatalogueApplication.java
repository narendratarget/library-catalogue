package com.library.cat;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.library.cat.model.Author;
import com.library.cat.model.Book;
import com.library.cat.model.Category;
import com.library.cat.model.Library;
import com.library.cat.repository.BookRepository;

@SpringBootApplication
public class LibraryCatalogueApplication implements CommandLineRunner{ 

	@Autowired
	BookRepository bookRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(LibraryCatalogueApplication.class, args);
	}

	
	@Override
	public void run(String... args) throws Exception {
		
		/*
		 * iNITIALIZE DEFAULT DATA TO DB
		 * */
		
		Library libraryBareilly=new Library();
		libraryBareilly.setAddress("Bareilly");
		
		Library libraryDelhi=new Library();
		libraryDelhi.setAddress("Delhi");
		
		Category business=new Category();
		business.setDescription("Business & Economics");
		
		Category fiction=new Category();
		fiction.setDescription("Fiction");
		
		Author napoleon=new Author();
		napoleon.setDesc("Napoleon Hill");
		
		Author chetan=new Author();
		chetan.setDesc("Chetan Bhagat");
		
		
		
		Book thinkAndGrow=new Book();
		thinkAndGrow.setDescription("Think & Grow Rich");
		thinkAndGrow.setPublicationYear(LocalDate.now().minusYears(1));
		thinkAndGrow.setCategory(business);
		thinkAndGrow.getLibraries().add(libraryBareilly);
		thinkAndGrow.setAuthor(napoleon);
		
		libraryBareilly.getBooks().add(thinkAndGrow);
		business.getBooks().add(thinkAndGrow);
		napoleon.getBooks().add(thinkAndGrow);
		
		Book subcounciousMind=new Book();
		subcounciousMind.setDescription("The Power of Your Subconscious Mind");
		subcounciousMind.setPublicationYear(LocalDate.now().minusYears(2));
		subcounciousMind.setCategory(business);
		subcounciousMind.getLibraries().add(libraryBareilly);
		subcounciousMind.getLibraries().add(libraryDelhi);
		subcounciousMind.setAuthor(napoleon);

		libraryBareilly.getBooks().add(subcounciousMind);
		libraryBareilly.getBooks().add(subcounciousMind);
		
		libraryDelhi.getBooks().add(subcounciousMind);
		
		business.getBooks().add(subcounciousMind);
		napoleon.getBooks().add(subcounciousMind);		
		
		Book arregedMurder=new Book();
		arregedMurder.setDescription("One Arranged Murder");
		arregedMurder.setPublicationYear(LocalDate.now().minusMonths(6));
		arregedMurder.setCategory(fiction);
		arregedMurder.getLibraries().add(libraryDelhi);
		arregedMurder.setAuthor(chetan);
		
		libraryDelhi.getBooks().add(arregedMurder);		
		
		fiction.getBooks().add(arregedMurder);
		
		chetan.getBooks().add(arregedMurder);
		
		bookRepository.save(thinkAndGrow);
		bookRepository.save(subcounciousMind);
		bookRepository.save(arregedMurder);
		
		
	}

}

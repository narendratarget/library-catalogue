package com.library.cat.exception;

public class ExceptionResponse {

	private String errorCode;
	private String errorDesc;
	private String message;
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "ExceptionResponse [errorCode=" + errorCode + ", errorDesc=" + errorDesc + ", message=" + message + "]";
	}
	
	
	
}

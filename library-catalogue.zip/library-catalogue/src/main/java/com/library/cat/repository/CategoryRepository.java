package com.library.cat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.library.cat.model.Category;

@Repository
public interface CategoryRepository extends JpaRepository<Category,Long>{

	Category findCategoryById(Long categoryId);

}

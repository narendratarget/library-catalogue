package com.library.cat.dto;

import java.util.List;

public class BookSearchResponse extends BaseResponse {

		List<BookData> books;

		public List<BookData> getBooks() {
			return books;
		}

		public void setBooks(List<BookData> books) {
			this.books = books;
		}

		@Override
		public String toString() {
			return "LibBookResponse [books=" + books + "]";
		}
		
		
}

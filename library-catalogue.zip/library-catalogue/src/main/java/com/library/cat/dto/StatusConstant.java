package com.library.cat.dto;

public interface StatusConstant {

	public static final String STATUS_SUCCESS="SUCCESS";
	public static final String STATUS_FAILURE="FAILURE";
	
}

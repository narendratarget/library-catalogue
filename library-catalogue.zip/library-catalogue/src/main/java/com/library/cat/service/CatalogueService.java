package com.library.cat.service;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.library.cat.dto.BaseResponse;
import com.library.cat.dto.BookRequest;
import com.library.cat.dto.BookSearchResponse;
import com.library.cat.dto.IndBookResponse;
import com.library.cat.dto.LibBookResponse;
import com.library.cat.exception.DataNotFoundException;
import com.library.cat.exception.InvalidRequestException;

@Service
public interface CatalogueService {
	
	public BookSearchResponse getBooksByFilter(@RequestParam("filter") String filter) throws DataNotFoundException, InvalidRequestException;

	public IndBookResponse getBookByBookId(Long bookId) throws DataNotFoundException;

	public IndBookResponse postNewBook(BookRequest request) throws InvalidRequestException;

	public IndBookResponse updateBook(Long bookId, BookRequest request) throws InvalidRequestException;

	public LibBookResponse getBooksByLibraryId(Long libraryId) throws DataNotFoundException, InvalidRequestException;

	public BaseResponse assignBookToLibrary(Long libraryId, Long bookId) throws InvalidRequestException;

}

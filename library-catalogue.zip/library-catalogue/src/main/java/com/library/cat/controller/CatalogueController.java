package com.library.cat.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.library.cat.dto.BaseResponse;
import com.library.cat.dto.BookRequest;
import com.library.cat.dto.BookSearchResponse;
import com.library.cat.exception.DataNotFoundException;
import com.library.cat.exception.InvalidRequestException;
import com.library.cat.service.CatalogueService;

@RestController
@RequestMapping
public class CatalogueController {
	
	@Autowired
	CatalogueService catalogueService;
	
	/*
	 * Below API filters data based on author_id or category_id , any one of the filters can be applied 
	 * 
	 * This can be done very effectively , with Spring Boot JPA Specifications if we have large set of filters to be enabled
	 * 
	 * Request Url : http://localhost:9090/books?filter=author_id:1
	 * 		   	   : http://localhost:9090/books?filter=category_id:1
	 * 
	 * */
	
	@GetMapping("/books")
	public BookSearchResponse getBooksByFilter(@RequestParam("filter") String filter) throws DataNotFoundException, InvalidRequestException {
		
		return catalogueService.getBooksByFilter(filter);
	}
	
	/*
	 * This API returns Book details for the bookId passed to it.
	 * 
	 * Request Url : http://localhost:9090/book/1
	 * 
	 * */

	@GetMapping("/book/{bookId}")
	public BaseResponse getBookByBookId(@PathVariable(name="bookId",required=true) Long bookId) throws DataNotFoundException{
		return catalogueService.getBookByBookId(bookId);
	}
	
	/*
	 * This API add new Book details to the system .
	 * 
	 * */	
	@PostMapping("/book")
	public BaseResponse postBook(@RequestBody final BookRequest request) throws InvalidRequestException{
		return catalogueService.postNewBook(request);
	}
	
	/*
	 * This API changes the Book details for the bookId passed to it.
	 * 
	 * */

	
	@PutMapping("/book/{bookId}")
	public BaseResponse postBook(@PathVariable(name="bookId",required=true) Long bookId,@RequestBody final BookRequest request) throws InvalidRequestException{
		return catalogueService.updateBook(bookId,request);
	}
	
	/*
	 * This API returns List of Books details for the libraryId passed to it.
	 * 
	 * */

	
	@GetMapping("/library/{libraryId}")
	public BaseResponse getBooksbyLibraryId(@PathVariable(name="libraryId",required=true) Long libraryId) throws DataNotFoundException, InvalidRequestException{
		return catalogueService.getBooksByLibraryId(libraryId);
	}
	
	/*
	 * This API assigns the book to the libarary as per the passed libraryId and bookId.
	 * 
	 * */
	
	
	@PostMapping("/library/{libraryId}/book/{bookId}/assignbook")
	public BaseResponse assignBookToLibrary(@PathVariable(name="libraryId",required=true) Long libraryId,@PathVariable(name="bookId",required=true) Long bookId) throws InvalidRequestException {
		return catalogueService.assignBookToLibrary(libraryId,bookId);
	}
	
	
}

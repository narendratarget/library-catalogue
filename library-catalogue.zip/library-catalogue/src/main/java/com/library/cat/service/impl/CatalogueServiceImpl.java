package com.library.cat.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.cat.dto.BaseResponse;
import com.library.cat.dto.BookData;
import com.library.cat.dto.BookRequest;
import com.library.cat.dto.BookSearchResponse;
import com.library.cat.dto.IndBookResponse;
import com.library.cat.dto.LibBookResponse;
import com.library.cat.dto.StatusConstant;
import com.library.cat.exception.DataNotFoundException;
import com.library.cat.exception.InvalidRequestException;
import com.library.cat.model.Author;
import com.library.cat.model.Book;
import com.library.cat.model.Category;
import com.library.cat.model.Library;
import com.library.cat.repository.AuthorRepository;
import com.library.cat.repository.BookRepository;
import com.library.cat.repository.CategoryRepository;
import com.library.cat.repository.LibraryRepository;
import com.library.cat.search.FilterRequest;
import com.library.cat.service.CatalogueService;

@Service
public class CatalogueServiceImpl implements CatalogueService {

	@Autowired
	BookRepository bookRepository;

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	AuthorRepository authorRepository;

	@Autowired
	LibraryRepository libraryRepository;

	@Override
	public BookSearchResponse getBooksByFilter(String filter) throws DataNotFoundException, InvalidRequestException {

		FilterRequest request = new FilterRequest(filter);
		BookSearchResponse response = new BookSearchResponse();

		if (request.getFilterType().equalsIgnoreCase("category_id")) {
			Optional<Category> categoryOptional=categoryRepository.findById(Long.parseLong(request.getFilterValue()));
			
			if (!categoryOptional.isPresent()) {
				throw new InvalidRequestException("103", "Invalid Category Id");
			}
			
			Category category=categoryOptional.get();
			if (category.getBooks().size() <= 0) {
				throw new DataNotFoundException("102", "Data Not Found");
			}

				List<BookData> books = category.getBooks().stream().map(item -> {

				BookData book = new BookData();
				book.setAuthorId(item.getAuthor().getId());
				book.setBookId(item.getId());
				book.setCategoryId(item.getCategory().getId());
				book.setDescription(item.getDescription());
				book.setPublicationYear(item.getPublicationYear());

				return book;

			}).collect(Collectors.toList());

			response.setStatus(StatusConstant.STATUS_SUCCESS);
			response.setBooks(books);
		
		} else if (request.getFilterType().equalsIgnoreCase("author_id")) {
			Optional<Author> authorOptional=authorRepository.findById(Long.parseLong(request.getFilterValue()));
			
			if (!authorOptional.isPresent()) {
				throw new InvalidRequestException("103", "Invalid Author Id");
			}

			Author author=authorOptional.get();
			
			if (author.getBooks().size() <= 0) {
				throw new DataNotFoundException("102", "Data Not Found");
			}


			List<BookData> books = author.getBooks().stream().map(item -> {

				BookData book = new BookData();
				book.setAuthorId(item.getAuthor().getId());
				book.setBookId(item.getId());
				book.setCategoryId(item.getCategory().getId());
				book.setDescription(item.getDescription());
				book.setPublicationYear(item.getPublicationYear());

				return book;

			}).collect(Collectors.toList());

			response.setStatus(StatusConstant.STATUS_SUCCESS);
			response.setBooks(books);
			
		} else {
			throw new InvalidRequestException("", "Filter Type is Invalid");
		}

		return response;
	}

	@Override
	public IndBookResponse getBookByBookId(Long bookId) throws DataNotFoundException {

		Optional<Book> bookOptional = bookRepository.findById(bookId);

		if (!bookOptional.isPresent()) {
			throw new DataNotFoundException("101", "Book not found with given Id");
		} else {

			Book book = bookOptional.get();
			IndBookResponse response = new IndBookResponse();

			response.setAuthorId(book.getAuthor().getId());
			response.setBookId(bookId);
			response.setCategoryId(book.getCategory().getId());
			response.setDescription(book.getDescription());
			response.setStatus(StatusConstant.STATUS_SUCCESS);
			response.setPublicationYear(book.getPublicationYear());
			return response;
		}

	}

	@Override
	public IndBookResponse postNewBook(BookRequest request) throws InvalidRequestException {
		if (request == null || request.getAuthorId() == null || request.getCategoryId() == null) {
			throw new InvalidRequestException("102", "Inavlid Request");
		}

		Optional<Category> categoryOptional = categoryRepository.findById(request.getCategoryId());

		if (!categoryOptional.isPresent()) {
			throw new InvalidRequestException("103", "Invalid Category Id");
		}

		Optional<Author> authorOptional = authorRepository.findById(request.getAuthorId());

		if (!authorOptional.isPresent()) {
			throw new InvalidRequestException("103", "Invalid Author Id");
		}

		Book book = new Book();

		Author author = authorOptional.get();
		Category category = categoryOptional.get();

		book.setAuthor(author);
		book.setCategory(category);
		book.setDescription(request.getDescription());
		book.setPublicationYear(request.getPublicationYear());

		category.getBooks().add(book);
		author.getBooks().add(book);

		Long bookId = bookRepository.save(book).getId();

		IndBookResponse response = new IndBookResponse();

		response.setAuthorId(author.getId());
		response.setBookId(bookId);
		response.setCategoryId(category.getId());
		response.setDescription(book.getDescription());
		response.setStatus(StatusConstant.STATUS_SUCCESS);
		response.setPublicationYear(book.getPublicationYear());

		return response;
	}

	@Override
	public IndBookResponse updateBook(Long bookId, BookRequest request) throws InvalidRequestException {

		if (bookId == null || request == null || request.getAuthorId() == null || request.getCategoryId() == null) {
			throw new InvalidRequestException("102", "Inavlid Request");
		}

		Optional<Category> categoryOptional = categoryRepository.findById(request.getCategoryId());

		if (!categoryOptional.isPresent()) {
			throw new InvalidRequestException("103", "Invalid Category Id");
		}

		Optional<Author> authorOptional = authorRepository.findById(request.getAuthorId());

		if (!authorOptional.isPresent()) {
			throw new InvalidRequestException("104", "Invalid Author Id");
		}

		Optional<Book> bookOptional = bookRepository.findById(bookId);

		if (!bookOptional.isPresent()) {
			throw new InvalidRequestException("105", "Invalid Book Id");
		}

		Book book = bookOptional.get();

		Author author = authorOptional.get();
		Category category = categoryOptional.get();

		book.setAuthor(author);
		book.setCategory(category);
		book.setDescription(request.getDescription());
		book.setPublicationYear(request.getPublicationYear());

		category.getBooks().add(book);
		author.getBooks().add(book);

		bookId = bookRepository.save(book).getId();

		IndBookResponse response = new IndBookResponse();

		response.setAuthorId(author.getId());
		response.setBookId(bookId);
		response.setCategoryId(category.getId());
		response.setDescription(book.getDescription());
		response.setStatus(StatusConstant.STATUS_SUCCESS);
		response.setPublicationYear(book.getPublicationYear());

		return response;

	}

	@Override
	public LibBookResponse getBooksByLibraryId(Long libraryId) throws DataNotFoundException, InvalidRequestException {

		if (libraryId == null) {
			throw new InvalidRequestException("102", "Invalid Request");
		}

		Optional<Library> libraryOptional = libraryRepository.findById(libraryId);

		if (!libraryOptional.isPresent()) {
			throw new InvalidRequestException("102", "Invalid Library Id");
		}

		Library library = libraryOptional.get();

		if (library.getBooks().size() <= 0) {
			throw new DataNotFoundException("102", "Data Not Found");
		}

		LibBookResponse response = new LibBookResponse();

		List<BookData> books = library.getBooks().stream().map(item -> {

			BookData book = new BookData();
			book.setAuthorId(item.getAuthor().getId());
			book.setBookId(item.getId());
			book.setCategoryId(item.getCategory().getId());
			book.setDescription(item.getDescription());
			book.setPublicationYear(item.getPublicationYear());

			return book;

		}).collect(Collectors.toList());

		response.setStatus(StatusConstant.STATUS_SUCCESS);
		response.setBooks(books);

		return response;
	}

	@Override
	public BaseResponse assignBookToLibrary(Long libraryId, Long bookId) throws InvalidRequestException {

		if (libraryId == null || bookId == null) {
			throw new InvalidRequestException("102", "Invalid Request");
		}

		Optional<Library> libraryOptional = libraryRepository.findById(libraryId);

		if (!libraryOptional.isPresent()) {
			throw new InvalidRequestException("102", "Invalid Library Id");
		}

		Library library = libraryOptional.get();

		Optional<Book> bookOptional = bookRepository.findById(bookId);

		if (!bookOptional.isPresent()) {
			throw new InvalidRequestException("102", "Invalid Book Id");
		}

		Book book = bookOptional.get();

		library.getBooks().add(book);
		book.getLibraries().add(library);

		libraryRepository.save(library);

		BaseResponse response = new BaseResponse();
		response.setStatus(StatusConstant.STATUS_SUCCESS);

		return response;
	}

}

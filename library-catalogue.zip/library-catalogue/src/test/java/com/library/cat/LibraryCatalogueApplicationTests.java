package com.library.cat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryCatalogueApplicationTests {

	@Test
	void contextLoads() {
	}

}
